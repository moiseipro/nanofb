function drlHandler() {
            block.removeEventListener("mousedown",mdHandler);
            block.addEventListener("mousedown",mddrlHandler);
        };
        
        function mddrlHandler(e){
            var elementId = 'element-'+Id;
            var style = "stroke:" +  stroke.value + ";stroke-width:6;stroke-dasharray:" + strokeDasharray.value + ";fill:transparent;"
            if (marker.value == "arrow") {
                markerType = "url(" + stroke.value + "arrow)";
            } else {
                markerType = "none";
            }
            ++Id;
            mX = svgMouseX;
            mY = svgMouseY;
            Qx2 = mX+2;
            Qy2 = mY;
            if ((lineType == '1')||(lineType == '3')) {
                line = SVG.createElement("path",{"d":`M ${mX} ${mY} L ${Qx2} ${Qy2}`,"style":style,"id":elementId,"marker-end":markerType});
            }
            if (lineType == '2') {
                Qx1 = mX+1;
                Qy1 = mY-1;
                line = SVG.createElement("path",{"d":`M ${mX} ${mY} Q ${Qx1} ${Qy1} ${Qx2} ${Qy2}`,"style":style,"id":elementId,"marker-end":markerType}); 
            }
            
            lines.appendChild(line);
            drag = block.getElementById(elementId);
            block.addEventListener("mousemove",mmdrlHandler);
            block.addEventListener("mouseup",mudrlHandler);
            
        };
        
        function mmdrlHandler(e){
            Qx2 = svgMouseX;
            Qy2 = svgMouseY;
            if ((lineType == '1')||(lineType == '3')) {
                drag.setAttribute("d",`M ${mX} ${mY} L ${Qx2} ${Qy2}`);
                
            }
            if (lineType == '2') {
                Qx1 = mX + (Qx2 - mX)/2;
                Qy1 = Qy2 - 50;
                drag.setAttribute("d",`M ${mX} ${mY} Q ${Qx1} ${Qy1}  ${Qx2} ${Qy2}`);
            }
        };
        
         function mudrlHandler(e){
            block.removeEventListener("mousemove",mmdrlHandler);
            block.removeEventListener("mousedown",mddrlHandler);
            if (lineType == '1') {
                block.removeEventListener("mouseup",mudrlHandler);
                block.addEventListener("mousedown",mdHandler);
            }
            if (lineType == '2') {
                block.addEventListener("mousemove",mm2drlHandler);
            }
             if (lineType == '3') {
                block.removeEventListener("mouseup",mudrlHandler);
                lineX = mX - Qx2;
                lineY = mY - Qy2;
                lineD = Math.sqrt(Math.pow(Math.abs(lineX), 2)+Math.pow(Math.abs(lineY), 2));
                pointCount = Math.floor(lineD/25);
                ratioLineXLineD = lineX/lineD;
                ratioLineYLineD = lineY/lineD;
                stepX = ratioLineXLineD*25;
                stepY = ratioLineYLineD*25;
                var z=0, cordiX, cordiY;
                newD = "M " + mX + " " + mY + " Q ";
                
                for (i = 0; i <= pointCount; i++) {
                    if (!even(i)) {
                        z++;
                        if(!even(z)){
                            cordiX = mX-stepY;
                            cordiY = mY+stepX;

                        } else {
                            cordiX = mX+stepY;
                            cordiY = mY-stepX;
                        }
                    } else {
                            cordiX = mX;
                            cordiY = mY;
                    }
                    if (i!=0) {newD += cordiX + " " + cordiY+ " "; }
                    mX = mX - stepX;
                    mY = mY - stepY;
                }
                newD += Qx2 + " " + Qy2;
               drag.setAttribute("d", newD);
                block.addEventListener("mousedown",mdHandler);
            }
        };
        
        function mm2drlHandler(e){
            Qx1 = svgMouseX;
            Qy1 = svgMouseY;
            drag.setAttribute("d",`M ${mX} ${mY} Q ${Qx1} ${Qy1} ${Qx2} ${Qy2}`);
            block.addEventListener("click",mcdrlHandler);
            
        };
        
        function mcdrlHandler(e){
            block.removeEventListener("mousemove",mm2drlHandler);
            block.removeEventListener("click",mcdrlHandler);
            block.removeEventListener("mouseup",mudrlHandler);
            block.addEventListener("mousedown",mdHandler);
        };