function crtHandler() {
            block.removeEventListener("mousedown",mdHandler);
            block.addEventListener("mousedown",mdcrtHandler);
        };
        
        function mdcrtHandler(e){
            var elementId='element-'+Id;
            console.log(objImg);
            object = SVG.createElement("image",{"href":objImg.img,"x":svgMouseX,"y":svgMouseY,"width":objImg.wdth,"height":objImg.hght,"id":elementId});
            objects.appendChild(object);
            block.removeEventListener("mousedown",mdcrtHandler);
            ++Id;
            block.addEventListener("mousedown",mdHandler);
        };

function mdHandler(e){
            drag = e.srcElement;
            if (e.which == 1) {
                if(drag instanceof SVGCircleElement){
                   
                    drag.crdX = drag.getAttribute("cx");
                    drag.crdY = drag.getAttribute("cy");
                    drag.clientX = svgMouseX;
                    drag.clientY = svgMouseY;
                    if (drag.id == '') {drag.object = drag.getAttribute("data-object");}
                    block.addEventListener("mousemove",mmHandler);
                    block.addEventListener("mouseup",muHandler);
                }
                
                if(drag instanceof SVGRectElement){
                   
                    drag.crdX = drag.getAttribute("x");
                    drag.crdY = drag.getAttribute("y");
                    drag.clientX = svgMouseX;
                    drag.clientY = svgMouseY;
                    if (drag.id == ''){
                        drag.object = drag.getAttribute("data-object");
                        block.addEventListener("mousemove",mmRHandler);
                        block.addEventListener("mouseup",muRHandler);
                    } else {
                        block.addEventListener("mousemove",mmObjHandler);
                        block.addEventListener("mouseup",muObjHandler);
                    }
                }
                if((drag instanceof SVGImageElement)&&(drag.id != 'plane')){
                    drag.crdX = drag.getAttribute("x");
                    drag.crdY = drag.getAttribute("y");
                    drag.clientX = svgMouseX;
                    drag.clientY = svgMouseY;
                    block.addEventListener("mousemove",mmObjHandler);
                    block.addEventListener("mouseup",muObjHandler);
                }
            }
            if (e.which == 2) {
                if((drag instanceof SVGPathElement)||(drag instanceof SVGPolygonElement)||((drag instanceof SVGImageElement)&&(drag.id != 'plane'))||(((drag instanceof SVGCircleElement)||(drag instanceof SVGRectElement))&&(drag.id != ''))){
                    var parent    = drag.parentNode;
                    points = document.querySelectorAll('[data-object="'+drag.id+'"]');
                    points.forEach(function(point){
                        dots.removeChild(point);
                    });
                    parent.removeChild(drag);
                }
            }
        }

        function mmHandler(e){
            drag.setAttribute("cx",svgMouseX - (drag.clientX - drag.crdX));
            drag.setAttribute("cy",svgMouseY - (drag.clientY - drag.crdY));
            if (drag.id == '') {
                points = document.querySelectorAll('[data-object="'+drag.object+'"]');
                if (points.length == 4) {
                    d = {x1:points[0].getAttribute("cx"),y1:points[0].getAttribute("cy"),x2:points[1].getAttribute("cx"),y2:points[1].getAttribute("cy"),x3:points[2].getAttribute("cx"),y3:points[2].getAttribute("cy"),x4:points[3].getAttribute("cx"),y4:points[3].getAttribute("cy")};
                    switch( drag ){
                        case points[0]:
                            d.x1 = drag.getAttribute("cx");
                            d.y1 = drag.getAttribute("cy"); break;    
                        case points[1]:
                            d.x2 = drag.getAttribute("cx");
                            d.y2 = drag.getAttribute("cy"); break;
                        case points[2]:
                            d.x3 = drag.getAttribute("cx");
                            d.y3 = drag.getAttribute("cy"); break; 
                        case points[3]:
                            d.x4 = drag.getAttribute("cx");
                            d.y4 = drag.getAttribute("cy"); break; 
                    }
                    block.getElementById(drag.object).setAttribute("points",`${d.x1},${d.y1} ${d.x2},${d.y2} ${d.x3},${d.y3} ${d.x4},${d.y4}`);
                }
                if (points.length == 3) {
                    d = {x1:points[0].getAttribute("cx"),y1:points[0].getAttribute("cy"),x2:points[1].getAttribute("cx"),y2:points[1].getAttribute("cy"),x3:points[2].getAttribute("cx"),y3:points[2].getAttribute("cy")};
                    switch( drag ){
                        case points[0]:
                            d.x1 = drag.getAttribute("cx");
                            d.y1 = drag.getAttribute("cy"); break;    
                        case points[1]:
                            d.x2 = drag.getAttribute("cx");
                            d.y2 = drag.getAttribute("cy"); break;
                        case points[2]:
                            d.x3 = drag.getAttribute("cx");
                            d.y3 = drag.getAttribute("cy"); break;      
                    }
                    block.getElementById(drag.object).setAttribute("d",`M ${d.x1} ${d.y1} Q ${d.x2} ${d.y2} ${d.x3} ${d.y3}`);
                }
                if (points.length == 2) {
                    d = {x1:points[0].getAttribute("cx"),y1:points[0].getAttribute("cy"),x2:points[1].getAttribute("cx"),y2:points[1].getAttribute("cy")};
                    switch( drag ){
                        case points[0]:
                            d.x1 = drag.getAttribute("cx");
                            d.y1 = drag.getAttribute("cy"); break;    
                        case points[1]:
                            d.x2 = drag.getAttribute("cx");
                            d.y2 = drag.getAttribute("cy"); break;
                    }
                    block.getElementById(drag.object).setAttribute("d",`M ${d.x1} ${d.y1} L ${d.x2} ${d.y2}`);
                }
            }
        }
        
        function muHandler(e){
            block.removeEventListener("mousemove",mmHandler);
            block.removeEventListener("mouseup",muHandler);
        }

function mmRHandler(e){
           
            resizeableObject = document.getElementById(drag.object);
            ratioObject = resizeableObject.getAttribute("height")/resizeableObject.getAttribute("width");
            resizeableObject.w = svgMouseX - (drag.clientX - drag.crdX) - resizeableObject.getAttribute("x") ;
            resizeableObject.h = (svgMouseX - (drag.clientX - drag.crdX) - resizeableObject.getAttribute("x"))*ratioObject;
            
            if (resizeableObject.w < 30) {resizeableObject.w = 30;resizeableObject.h = resizeableObject.w*ratioObject;}
            
            drag.setAttribute("y", +resizeableObject.getAttribute("y") + resizeableObject.h);
            drag.setAttribute("x", +resizeableObject.getAttribute("x") + resizeableObject.w);
            
            resizeableObject.setAttribute("width", resizeableObject.w ); resizeableObject.setAttribute("height", resizeableObject.h );
        }

function muRHandler(e){
            block.removeEventListener("mousemove",mmRHandler);
            block.removeEventListener("mouseup",muRHandler);
        }
        
        
        function mmObjHandler(e){
            drag.setAttribute("x",svgMouseX - (drag.clientX - drag.crdX));
            drag.setAttribute("y",svgMouseY - (drag.clientY - drag.crdY));
            drag.setAttribute("filter","url(#f3)");
            
        }
        
        function muObjHandler(e){
            drag.removeAttribute("filter","url(#f3)");
            block.removeEventListener("mousemove",mmObjHandler);
            block.removeEventListener("mouseup",muObjHandler);
        }
function cmHandler(e){
            e.preventDefault();
            drag = e.srcElement;
            if (drag.getAttribute("data-select") == 1){
                    drag.setAttribute("data-select","0");
                    points = document.querySelectorAll('[data-object="'+drag.id+'"]');
                    points.forEach(function(point){
                        dots.removeChild(point);
                    });
            } else {
                drag.setAttribute("data-select","1");
                if((drag instanceof SVGImageElement)&&(drag.id != 'plane')){
                    var pointX = Number(drag.getAttribute("x")) + Number(drag.getAttribute("width"));
                    var pointY = Number(drag.getAttribute("y")) + Number(drag.getAttribute("height"));
                    point = SVG.createElement("rect",{"x":pointX,"y":pointY,"width":20,"height":20,"stroke":"red","fill":"red","data-object":drag.getAttribute("id")}); 
                    dots.appendChild(point);
                } 
                if(drag instanceof SVGPathElement){
                    var points =  drag.getAttribute("d");
                    var points_array = points.split(" ");
                    var p1=[],p2=[],p3=[];
                    if (points_array.length == 8) {
                        p1.X = points_array[1];
                        p1.Y = points_array[2];
                        p2.X = points_array[4];
                        p2.Y = points_array[5];
                        p3.X = points_array[6];
                        p3.Y = points_array[7];
                        dots.appendChild(SVG.createElement("circle",{"cx":p1.X,"cy":p1.Y,"r":10,"stroke":"red","fill":"red","data-object":drag.getAttribute("id"),"data-point":"p1"}));
                        dots.appendChild(SVG.createElement("circle",{"cx":p2.X,"cy":p2.Y,"r":10,"stroke":"red","fill":"red","data-object":drag.getAttribute("id"),"data-point":"p2"}));
                        dots.appendChild(SVG.createElement("circle",{"cx":p3.X,"cy":p3.Y,"r":10,"stroke":"red","fill":"red","data-object":drag.getAttribute("id"),"data-point":"p3"}));
                    };
                    if (points_array.length == 6) {
                        p1.X = points_array[1];
                        p1.Y = points_array[2];
                        p2.X = points_array[4];
                        p2.Y = points_array[5];
                        dots.appendChild(SVG.createElement("circle",{"cx":p1.X,"cy":p1.Y,"r":10,"stroke":"red","fill":"red","data-object":drag.getAttribute("id"),"data-point":"p1"}));
                        dots.appendChild(SVG.createElement("circle",{"cx":p2.X,"cy":p2.Y,"r":10,"stroke":"red","fill":"red","data-object":drag.getAttribute("id"),"data-point":"p2"}));
                    };
                } 
                if(drag instanceof SVGPolygonElement){
                    var points =  drag.getAttribute("points"),
                    points_array = points.split(" "),
                    p1 = points_array[0].split(","),
                    p2 = points_array[1].split(","),
                    p3 = points_array[2].split(","), 
                    p4 = points_array[3].split(",");
                    if (points_array.length == 4) {
                        dots.appendChild(SVG.createElement("circle",{"cx":p1[0],"cy":p1[1],"r":10,"stroke":"red","fill":"red","data-object":drag.getAttribute("id"),"data-point":"p1"}));
                        dots.appendChild(SVG.createElement("circle",{"cx":p2[0],"cy":p2[1],"r":10,"stroke":"red","fill":"red","data-object":drag.getAttribute("id"),"data-point":"p2"}));
                        dots.appendChild(SVG.createElement("circle",{"cx":p3[0],"cy":p3[1],"r":10,"stroke":"red","fill":"red","data-object":drag.getAttribute("id"),"data-point":"p3"}));
                        dots.appendChild(SVG.createElement("circle",{"cx":p4[0],"cy":p4[1],"r":10,"stroke":"red","fill":"red","data-object":drag.getAttribute("id"),"data-point":"p4"}));
                    };
               }
            } 
        }